package com.micro.orderservice.dto;

public class OrderResponse {
}
