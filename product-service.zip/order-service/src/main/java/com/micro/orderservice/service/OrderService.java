package com.micro.orderservice.service;

import com.micro.orderservice.dto.OrderRequest;

public interface OrderService {

    public void pleceOrder(OrderRequest orderRequest) throws IllegalAccessException;
}
