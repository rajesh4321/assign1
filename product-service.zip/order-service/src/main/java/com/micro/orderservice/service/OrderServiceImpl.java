package com.micro.orderservice.service;

import com.micro.orderservice.dto.InventoryResponse;
import com.micro.orderservice.dto.OrderLineItemsDto;
import com.micro.orderservice.dto.OrderRequest;
import com.micro.orderservice.model.Order;
import com.micro.orderservice.model.OrderLineItems;
import com.micro.orderservice.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class OrderServiceImpl implements OrderService{

    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private WebClient.Builder webClient;

    @Override
    public void pleceOrder(OrderRequest orderRequest) throws IllegalAccessException {
        Order order = new Order();
        order.setOrderNumber(UUID.randomUUID().toString());

        List<OrderLineItems> orderLineItems = orderRequest.getOrderLineItemsDtos()
                .stream().map(orderLineItemsDto -> mapToOrderLineItemsDto(orderLineItemsDto))
                .collect(Collectors.toList());

        order.setOrderLineItems(orderLineItems);

        List<String> items = order.getOrderLineItems().stream()
                .map(OrderLineItems::getItemCode).collect(Collectors.toList());

        //check inventory status
        InventoryResponse[] result = webClient.build().get()
                .uri("http://inventory-service/inventory/getStatus",
                        uriBuilder -> uriBuilder.queryParam("itemCode", items).build())
                .retrieve().bodyToMono(InventoryResponse[].class)
                .block();

//        ResponseEntity<InventoryResponse[]> responses = new RestTemplate()
//                .getForEntity("http://inventory-service/inventory/getStatus?itemCode=iPhone_13",
//                 InventoryResponse[].class);
//        InventoryResponse[]  inventoryResponses = responses.getBody();

        boolean allProductInStock = Arrays.stream(result).allMatch(InventoryResponse::isInStock);
        
        if(allProductInStock) {
            orderRepository.save(order);
        }else {
            throw new IllegalAccessException("Product is not in stock, Please try after some time!");
        }
    }

    private OrderLineItems mapToOrderLineItemsDto(OrderLineItemsDto orderLineItemsDto) {
        return OrderLineItems.builder()
                .itemCode(orderLineItemsDto.getItemCode())
                .price(orderLineItemsDto.getPrice())
                .quantity(orderLineItemsDto.getQuantity())
                .build();
    }
}
