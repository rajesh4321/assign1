package com.micro.productservice.service;

import com.micro.productservice.dto.ProductRequest;
import com.micro.productservice.dto.ProductResponse;

import java.util.List;

public interface ProductService {

    public ProductResponse createProduct(ProductRequest productRequest);

    public List<ProductResponse> getAllProductList();
}
