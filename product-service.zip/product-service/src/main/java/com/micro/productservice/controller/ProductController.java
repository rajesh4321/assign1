package com.micro.productservice.controller;

import com.micro.productservice.dto.ProductRequest;
import com.micro.productservice.dto.ProductResponse;
import com.micro.productservice.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/product")
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping("/add")
    public ResponseEntity<ProductResponse> createProduct(@RequestBody ProductRequest productRequest){
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(productService.createProduct(productRequest));
    }

    @GetMapping("/getAllProduct")
    public ResponseEntity<List<ProductResponse>> getProduct(){
        return ResponseEntity.status(HttpStatus.OK).body(productService.getAllProductList());
    }
    @GetMapping("/test")
    public String test(){
        return "test";
    }
}
