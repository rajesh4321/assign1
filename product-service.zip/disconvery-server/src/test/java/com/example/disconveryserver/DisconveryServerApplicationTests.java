package com.example.disconveryserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DisconveryServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
