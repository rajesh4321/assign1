package com.micro.inventoryservice.dto;

public class InventoryRequest {
}
