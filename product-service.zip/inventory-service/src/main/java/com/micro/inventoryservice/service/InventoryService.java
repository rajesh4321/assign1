package com.micro.inventoryservice.service;

import com.micro.inventoryservice.dto.InventoryResponse;
import com.micro.inventoryservice.model.Inventory;

import java.util.List;

public interface InventoryService {
    public List<InventoryResponse> checkStatus(List<String> itemCode);
}
