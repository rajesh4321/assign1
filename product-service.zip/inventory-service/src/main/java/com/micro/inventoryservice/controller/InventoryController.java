package com.micro.inventoryservice.controller;

import com.micro.inventoryservice.dto.InventoryResponse;
import com.micro.inventoryservice.model.Inventory;
import com.micro.inventoryservice.service.InventoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/inventory")
public class InventoryController {

    @Autowired
    private InventoryService inventoryService;

    @GetMapping("getStatus")
    public ResponseEntity<List<InventoryResponse>> getStatus(@RequestParam("itemCode") List<String> itemCode){
        return ResponseEntity.status(HttpStatus.OK).body(inventoryService.checkStatus(itemCode));
    }
}
