package com.micro.inventoryservice.service;

import com.micro.inventoryservice.dto.InventoryResponse;
import com.micro.inventoryservice.model.Inventory;
import com.micro.inventoryservice.repository.InventoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class InventoryServiceImpl implements InventoryService{

    @Autowired
    private InventoryRepository inventoryRepository;

    @Override
    public List<InventoryResponse> checkStatus(List<String> itemCode) {
        return inventoryRepository.findByItemCodeIn(itemCode).stream()
                .map(inventory -> {
                    return InventoryResponse.builder()
                            .itemCode(inventory.getItemCode())
                            .isInStock(inventory.getQuantity()>0)
                            .build();
                }).collect(Collectors.toList());
    }
}
